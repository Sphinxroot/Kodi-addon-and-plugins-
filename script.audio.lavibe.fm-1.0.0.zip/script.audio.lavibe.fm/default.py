﻿
import xbmc

xbmc.executebuiltin( "PlayMedia(https://stream.lavibe.fm/chxx.aac)" )