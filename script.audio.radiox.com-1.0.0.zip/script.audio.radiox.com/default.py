
import xbmc

xbmc.executebuiltin( "PlayMedia(https://lb0-stream.radiox981.ca/choi.mp3)" )